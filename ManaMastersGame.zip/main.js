
function startGame() {
  document.querySelector('button').style.display = 'none';
  document.getElementById('gameArea').style.display = 'block';
}
